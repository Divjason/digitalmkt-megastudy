const showPosition = (position) => {
  const { latitude, longitude } = position.coords;
  var container = document.getElementById("map"); //지도를 담을 영역의 DOM 레퍼런스
  var options = {
    //지도를 생성할 때 필요한 기본 옵션
    center: new kakao.maps.LatLng(latitude, longitude), //지도의 중심좌표.
    level: 3, //지도의 레벨(확대, 축소 정도)
  };

  var map = new kakao.maps.Map(container, options); //지도 생성 및 객체 리턴

  var positions = [
    {
      title:
        '<div style="padding:5px;"><a href="https://megaitacademy.com/" target="_blank">메가스터디IT</a></div>',
      latlng: new kakao.maps.LatLng(latitude, longitude),
    },
    {
      title: '<div style="padding:5px;">올리브영 신논현점</div>',
      latlng: new kakao.maps.LatLng(37.507154, 127.0226613),
    },
    {
      title: '<div style="padding:5px;">올리브영 신논현역점</div>',
      latlng: new kakao.maps.LatLng(37.506448, 127.0282318),
    },
    {
      title: '<div style="padding:5px;">이삭토스트 강남점</div>',
      latlng: new kakao.maps.LatLng(37.4956704, 127.0271964),
    },
  ];
  // 마커가 표시될 위치입니다
  // var markerPosition = new kakao.maps.LatLng(latitude, longitude);

  for (let i = 0; i < positions.length; i++) {
    // 마커를 생성합니다
    var marker = new kakao.maps.Marker({
      map: map,
      position: positions[i].latlng,
    });

    // 인포윈도우를 생성합니다
    var infowindow = new kakao.maps.InfoWindow({
      content: positions[i].title,
      removable: true,
    });

    // 마커에 클릭이벤트를 등록합니다
    /*
    kakao.maps.event.addListener(marker, "click", function () {
      // 마커 위에 인포윈도우를 표시합니다
      infowindow.open(map, marker);
    });
    */

    const makeOverListener = (map, marker, infowindow) => {
      return () => {
        infowindow.open(map, marker);
      };
    };

    const makeOutListener = (infowindow) => {
      return () => {
        infowindow.close();
      };
    };

    kakao.maps.event.addListener(
      marker,
      "mouseover",
      makeOverListener(map, marker, infowindow)
    );

    kakao.maps.event.addListener(
      marker,
      "mouseout",
      makeOutListener(infowindow)
    );

    // 마커가 지도 위에 표시되도록 설정합니다
    marker.setMap(map);
  }

  // 마커를 클릭했을 때 마커 위에 표시할 인포윈도우를 생성합니다
  /*
  var iwContent =
      '<div style="padding:5px;"><a href="https://megaitacademy.com/" target="_blank">메가스터디IT</a></div>', // 인포윈도우에 표출될 내용으로 HTML 문자열이나 document element가 가능합니다
    iwRemoveable = true; // removeable 속성을 ture 로 설정하면 인포윈도우를 닫을 수 있는 x버튼이 표시됩니다
  */
};

const errorPosition = (err) => {
  alert(err.message);
};

if (navigator.geolocation) {
  navigator.geolocation.getCurrentPosition(showPosition, errorPosition);
} else {
  alert("Geolocation을 지원하지 않는 기기입니다.");
}
